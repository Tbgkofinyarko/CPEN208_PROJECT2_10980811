import React, { useState } from "react";
import uglogo from './uglogo.jpg';

export const LoginPage = (props) => {
    const [email, setEmail] = useState('')
    const [password, setPass] = useState('')
    
    const handleSubmit = (e) => {
        e.preventDefault();
        const isValidLogin = email === "example@example.com" && password === "password";
        if (isValidLogin) {
          props.onFormSwitch('dashboard');
        } else {
          console.log("Invalid login"); 
        }
      };
    return (
        <div className="auth-form-container">
            <img className="logo" src={uglogo} alt="UG Logo" />
        <h1>WELCOME TO UNIVERSITY OF GHANA STUDENT PORTAL</h1>
        <h2>LOG IN TO ACCESS YOUR DASHBOARD</h2>
       <form className="loginpage-form" onSubmit = {handleSubmit}> 
                <label htmlFor ="email">Email</label>
                <input value = {email} onChange={(e) => setEmail(e.target.value)} type ="email" placeholder="youremail@st.ug.edu.gh" id ="email" name ="email"/>
                <label htmlFor ="password">Password</label>
                <input value = {password} onChange={(e) => setPass(e.target.value)} type ="password" placeholder="**********" id ="password" name ="password"/>
                <button className="glowing-btn glowing-txt faulty-letter" onClick ={ () => props.onFormSwitch('dashboard')} type = "submit">Log In</button>
        </form>
        <button className="link-btn" onClick ={ () => props.onFormSwitch('registration')}>Don't have an account? Register here</button>
        </div>
    )
}
export default LoginPage;