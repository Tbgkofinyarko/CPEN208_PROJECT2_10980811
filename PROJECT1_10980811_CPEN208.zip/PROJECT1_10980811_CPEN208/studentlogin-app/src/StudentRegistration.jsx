import React, { useState } from "react";

export const StudentRegistration = (props) => {
  const [email, setEmail] = useState("");
  const [password, setPass] = useState("");
  const [name, setName] = useState("");

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPass(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(email);
    props.onFormSwitch('infoEntry');
  };
  

  const handleFormSwitch = () => {
    props.onFormSwitch("LoginPage");
  };

  return (
    <div className="auth-form-container">
      <h1>CREATE YOUR STUDENT ACCOUNT</h1>
      <form className="studentregistration-form" onSubmit={handleSubmit}>
        <label htmlFor="name">Full name</label>
        <input
          value={name}
          name="name"
          placeholder="Full name"
          id="name"
          onChange={handleNameChange}
          autoComplete="name"
          required
        />
        <label htmlFor="email">Email</label>
        <input
          value={email}
          type="email"
          placeholder="youremail@st.ug.edu.gh"
          id="email"
          name="email"
          onChange={handleEmailChange}
          autoComplete="email" // Changed to autoComplete instead of autocomplete
          required
        />
        <label htmlFor="password">Password</label>
        <input
          value={password}
          type="password"
          placeholder="**********"
          id="password"
          name="password"
          onChange={handlePasswordChange}
          autoComplete="new-password"
          required
        />
        <button className="glowing-btn glowing-txt faulty-letter" type="submit">Log In</button>
      </form>
      <button className="link-btn" onClick={() => props.onFormSwitch('login')}>
      Already have an account? Log in here
      </button>
 </div>
  );
};
export default StudentRegistration;