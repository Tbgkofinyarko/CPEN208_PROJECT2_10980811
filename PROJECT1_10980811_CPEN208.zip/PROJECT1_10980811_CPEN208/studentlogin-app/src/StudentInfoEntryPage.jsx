import React, { useState } from "react";

export const StudentInfoEntryPage = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [major, setMajor] = useState('');
  const [StudentID, setStudentID] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const details = { name, age, major, StudentID };
    onSubmit(details);
  }

  return (
    <div className="info-entry-container">
      <h1>Student Info Entry</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name</label>
        <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required />

        <label htmlFor="age">Age</label>
        <input type="number" id="age" value={age} onChange={(e) => setAge(e.target.value)} required/>

        <label htmlFor="major">Major</label>
        <input type="text" id="major" value={major} onChange={(e) => setMajor(e.target.value)} required/>
        
        <label htmlFor="StudentID">StudentID</label>
        <input type="number" id="StudentID" value={StudentID} onChange={(e) => setStudentID(e.target.value)} required/>

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};
