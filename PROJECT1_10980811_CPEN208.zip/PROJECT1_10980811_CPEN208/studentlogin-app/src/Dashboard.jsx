import React from "react";

export const Dashboard = ({ studentDetails }) => {
  return (
    <div className="dashboard-container">
      <h1>Welcome to the Dashboard!</h1>
      {studentDetails ? (
        <div className="details-card">
          <h2>Student Details</h2>
          <p>
            <strong>Name:</strong> {studentDetails.name}
          </p>
          <p>
            <strong>Age:</strong> {studentDetails.age}
          </p>
          <p>
            <strong>Major:</strong> {studentDetails.major}
          </p>
        </div>
      ) : (
        <p>No student details available.</p>
      )}
    </div>
  );
};

export default Dashboard;
